# Build Prompts — LetsVibeAI

## Phase 1: Conversion-led public site
```text
You are the frontend implementation agent for LetsVibeAI. Build a responsive public marketing experience that positions LetsVibeAI as a practical academy for learning and shipping AI-powered projects. Preserve the existing six-module curriculum and three labs. Add pages/sections for outcome-driven hero, project ladder, workspace preview, learner projects, Free vs Builder comparison, trust/safety, and account CTA.

Constraints: AWS-only backend; no invented testimonials; accessible semantic HTML; mobile-first; instrumentation hooks for landing_view, cta_clicked, and account_created. Do not add billing, deployment, or external integrations. Return changed-file plan, component map, test plan, and preview-ready implementation.
```

## Phase 2: Learner dashboard and PAL project brief
```text
You are the product/full-stack agent. Build the authenticated LetsVibeAI learner dashboard. Implement goal-based onboarding, course/lab progress, project creation, and a PAL project brief flow. The brief must preserve verbatim learner input, distinguish stated requirements, assumptions, enhancements, and open decisions, and persist a structured project contract.

Do not call external tools or use secrets. Include JSON schema validation, authorization checks, seed data, unit tests, and event capture for onboarding_completed, module_completed, project_created, and pal_brief_generated.
```

## Phase 3: Builder Workspace and sandbox MVP
```text
You are the secure platform engineer. Implement a quota-aware Builder Workspace with chat UI, project artifact panel, sandbox run controls, logs, preview state, reset, and checkpoints. The sandbox supports one approved template only. It must be isolated, short-lived, resource-bounded, egress-restricted by default, and unable to access long-lived credentials or internal metadata endpoints.

Do not deploy publicly or connect billing. Produce infrastructure plan, threat model, policy tests, teardown test, metering events, and an approval request for any production environment action.
```

## Phase 4: Monetization and learning retention
```text
You are the growth systems agent. Add an entitlement-ready Builder offer flow at the approved price and plan limits. Instrument checkout_started, subscription_activated, subscription_cancelled, workspace_opened, sandbox_run_requested, sandbox_run_succeeded, and sandbox_run_failed. Build lifecycle message drafts only; do not send messages. Provide cohort dashboard requirements, cancellation reasons, and experiment report template.
```
