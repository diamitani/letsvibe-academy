# LetsVibeAI Metrics and Experiment Backlog

## North-star behavior
A learner creates a project brief, completes a meaningful build milestone, and returns to continue building.

## Funnel
| Stage | Event | Question |
|---|---|---|
| Acquisition | landing_view | Which channels produce relevant visitors? |
| Intent | cta_clicked | Does the promise motivate action? |
| Registration | account_created | Is sign-up friction acceptable? |
| Activation | onboarding_completed, module_completed | Do learners reach the first value moment? |
| Build | project_created, pal_brief_generated | Do lessons convert into project intent? |
| Execution | sandbox_run_succeeded | Can learners make real progress? |
| Revenue | checkout_started, subscription_activated | Does workspace value justify payment? |
| Retention | workspace_opened, module_completed, project_shared | Do learners return and complete? |

## First experiments
1. **Outcome-first hero:** Compare “learn vibe coding” against “build your first useful project.” Measure CTA and account conversion.
2. **Project-brief activation:** Offer project creation after module two versus after onboarding. Measure first project creation and week-one return.
3. **Workspace paywall moment:** Compare upgrade prompt at project persistence versus first sandbox run. Measure checkout starts without harming project completion.
4. **Guided milestone nudge:** Send or show an opt-in next-step reminder only after an incomplete milestone. Measure return and completion; do not send without consent.

## Guardrail metrics
Track compute cost per successful sandbox run, sandbox failure rate, policy-denied actions, support contacts per active learner, refund/cancellation rate, and reported unsafe outputs. Stop or revise an experiment when a guardrail degrades materially.
