---
id: letsvibeai-learning-workspace-planner
name: LetsVibeAI Learning Workspace Planner
version: 1.0.0
status: draft
owner: rostr-pal-skill-builder
category: planning
trigger: A LetsVibeAI product, growth, curriculum, workspace, or sandbox decision needs a grounded plan and a testable next step.
inputs:
  - name: product_request
    required: true
    description: The proposed product, growth, curriculum, workspace, or sandbox change.
  - name: project_context
    required: true
    description: Current course, plans, known constraints, metrics, and approved technology boundaries.
outputs:
  - name: decision_package
    format: markdown
    description: A traceable recommendation with plan, risks, measures, and approval gates.
allowed_tools:
  - project-file-search
  - approved-web-research
  - artifact-store
  - analytics-read
  - sandbox-read
 denied_tools:
  - production-deployment
  - billing-changes
  - external-messaging
  - secret-access
  - destructive-data-actions
requires_approval_for:
  - pricing-or-billing-change
  - external-file-ingestion
  - public-deployment
  - third-party-account-connection
  - production-sandbox-execution
memory_namespace: project/{project_id}
---

# LetsVibeAI Learning Workspace Planner

## Purpose
Turn a LetsVibeAI opportunity into the smallest valuable, safe, revenue-aware learning-and-building experiment.

## Use when
- Planning a course, lab, workspace, chat, sandbox, monetization, onboarding, retention, or project-template change.
- A learner request must become a PAL project brief and a structured build path.

## Do not use when
- The request is a simple editorial correction with no impact on learning flow, product behavior, pricing, or safety.
- The action would directly modify production, bill a user, or publish externally; route that action to the appropriate approved execution workflow.

## Inputs
| Input | Required | Validation | Notes |
|---|---:|---|---|
| product_request | Yes | States desired outcome or observed problem | Preserve original wording |
| project_context | Yes | Includes known constraints and existing artifacts | AWS-only unless explicitly changed |
| evidence | No | Links/metrics/source register | Required for external or current claims |

## Outputs
| Output | Format | Definition of done |
|---|---|---|
| decision_package | Markdown | Includes scope, JTBD, NPAO priority, MVP, measures, risks, and next action |
| project_contract_update | YAML | Labels stated requirements, assumptions, approvals, and owners |

## Procedure
1. Classify the request as acquisition, activation, learning, monetization, retention, sandbox safety, or platform capability.
2. Extract stated requirements, inferred requirements, non-goals, constraints, and material open decisions.
3. Write user, system, build, and operational JTBD statements.
4. Check available product analytics and relevant course/project artifacts before external research.
5. If evidence is needed, create tiered RAG-DAL research targets; do not treat community commentary as sole support for a material decision.
6. Rank options with NPAO. Dependencies, security, learner trust, and explicit commitments override a numeric score.
7. Recommend the smallest reversible experiment with success metric, failure signal, owner, cost/usage boundary, and rollback.
8. Create approval requests for pricing, billing, public deployment, third-party connections, private data use, or consequential sandbox execution.
9. Update the project contract and return a concise decision package.

## Guardrails
- Do not assume a paywall is justified; connect every paid feature to an ongoing value loop or measurable cost.
- Keep foundational education accessible; charge for persistent workspace, guidance, compute, templates, collaboration, or advanced execution value.
- Do not expose credentials in prompt, artifact, or log output. Use `ENV:<NAME>` references.
- Sandbox recommendations must use isolation, bounded resources, restricted egress, checkpointing, and teardown.
- Do not represent a recommendation, price, or projection as validated without evidence.

## Quality checks
- [ ] The outcome and target learner are explicit.
- [ ] Every proposed feature maps to a job, metric, and test.
- [ ] The plan distinguishes existing facts, assumptions, and optional expansion.
- [ ] Cost-bearing resources have a quota/metering or approval policy.
- [ ] External or irreversible actions have a named approval gate.

## Failure and escalation
| Condition | Action |
|---|---|
| No baseline metrics | Define instrumentation first; do not claim conversion impact |
| Material audience ambiguity | Ask one focused learner/segment question |
| Sandbox safety requirement unclear | Restrict to a non-production template and request architecture review |
| Pricing decision required | Frame an experiment, not a permanent change; request approval before implementation |

## Examples
### Input
```yaml
product_request: Add a personal AI workspace so students can build apps while taking the course.
project_context:
  curriculum: six free modules and three labs
  constraints: AWS-only; no production secrets in learner workspace
```

### Expected output
```yaml
recommendation: Launch a quota-bound Builder Workspace as a paid experiment after a free learner creates a project brief.
now:
  - Implement project brief, workspace entitlement, one isolated starter sandbox, and usage instrumentation.
metric: project_created_to_first_sandbox_run
approval_required:
  - billing configuration
  - public sandbox deployment
```

## Change log
- 1.0.0 — Initial LetsVibeAI integration skill.
